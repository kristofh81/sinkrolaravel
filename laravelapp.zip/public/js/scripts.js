$(function() {
   $( "#datepicker" ).datepicker({ dateFormat: "dd/mm/yy" ,minDate: 0, maxDate: "+1Y" });
  
});
